---
name: impeccable
description: Use when the user asks to do interaction design, Demo design, UI design, 交互设计、Demo 设计, or turn requirements into a runnable frontend application. Builds the requested application from the repository's default app template and basic components; not for backend-only work, design-only critique, or production hardening unless explicitly requested.
---

# Impeccable Demo Design

This repository is a default application template with a working frontend foundation and basic components. Use it to create the application the user requests. The current pages are replaceable examples, not product requirements: replace pages, routes, content, interactions, and visual direction as needed.

Create a complete, runnable frontend demo with a clear point of view, a coherent primary flow, and production-grade visual craft. The user's requirements win over the template's example content and generic preferences.

## Scope

- Reuse the template's project setup and basic components when useful.
- Implement the requested new application directly in this repository. Replace or remove the existing example pages instead of preserving them by default.
- Preserve only constraints, behavior, or content that the user explicitly asks to keep.
- Use realistic product language and representative mock data. Do not invent unsupported product claims.
- Default to one strong direction. If the user asks for alternatives, keep them inside the existing app and make comparison temporary and easy to remove.
- Treat mobile and responsive work as opt-in. Do not add breakpoints or mobile variants unless the request or supplied reference requires them.

## Workflow

### 1. Clarify the request

If the request is clear enough to determine the application, primary user goal, core pages, key interactions, and visual direction, proceed.

If any of those decisions are unclear and would materially change the result, ask focused questions before implementation and wait for the user's answers. Do not silently turn an ambiguous prompt into a specific product.

Read supplied references and directly relevant project context as needed. Do not perform a general audit of the template before starting.

### 2. Choose a compact direction

Before coding, settle on one coherent direction: primary path, information hierarchy, first-screen structure, interaction model, necessary states, and the intended visual character.

Do not create direction decks, design documents, or other intermediate artifacts unless requested. The implementation is the demo.

Match expression to the surface:

- Task-oriented apps, dashboards, editors, forms, and settings prioritize scanability, familiar controls, clear state, and efficient completion.
- Landing pages and campaigns may use stronger composition, imagery, and motion when the brief supports it.
- Reading surfaces prioritize comprehension, rhythm, and typography.
- Portfolios and showcases let the featured work lead while the interface recedes.

### 3. Implement the smallest coherent demo

- Build the core page or flow directly in the current project.
- Prefer existing components, tokens, icons, and conventions when they fit.
- Use local state and representative mocks for the main path; do not expand into full backend integration or every production edge case unless requested.
- Cover the states needed to understand the experience, such as loading, empty, error, selected, disabled, or success states when relevant.
- Make controls semantic and keyboard-usable, with visible focus and understandable feedback.
- Use motion only when it clarifies change, hierarchy, or cause and effect.

Avoid generic AI styling by default: grids of interchangeable icon cards, cards nested inside cards, decorative eyebrow labels, gratuitous gradients or glass effects, emoji as interface icons, arbitrary glows, and uniform entrance animations. Use any of these only when the brief gives them a real purpose.

### 4. Validate and refine

Run the smallest relevant non-build check available in the project, such as a focused typecheck, lint, or test.

Open the target route in a browser and inspect the rendered result when a browser tool is available. If no browser tool is available, skip browser validation and state that clearly; do not block the implementation.

Check the rendered demo in one focused pass:

- the first visual anchor, reading order, and primary action are obvious;
- spacing, alignment, typography, and color establish a consistent hierarchy;
- copy names the object and action clearly;
- important states do not rely on color alone;
- requested content and interactions are easy to find and use;
- there is no blank screen, clipped primary content, accidental overflow, or obscured control;
- the result feels specific to this product rather than reusable filler.

Fix the issues found in that pass, then recheck only what changed. Report what was implemented, what was validated, and any remaining limitation.
