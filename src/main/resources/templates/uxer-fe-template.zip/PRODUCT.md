# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

React、TypeScript 与 Vite。技术栈由用户明确指定。

## Users

主要用户是希望快速启动 UXer 项目的产品经理和前端开发者。他们需要进入应用后直接体验组件、设计页面和组合交互，而不是先理解平台接入或从空白工程搭建界面。

## Product Purpose

提供一个可直接克隆的 UXer 前端模板，默认具备本地开发、Sandbox Demo、Inspector Review、Publish 与一组可复用的基础组件。成功意味着用户安装依赖后即可运行，并能直接从组件体验区开始设计和评审页面。

## Positioning

它不是通用 Vite 示例，而是把 UXer 的仓库配置、Inspector 和 Publish 契约预先验证好的高质量应用起点。

## Operating Context

模板会被克隆为新项目，随后在本地开发，并由 UXer Sandbox 启动 Demo、定位页面元素、添加 Review 评论和生成独立发布版本。

## Capabilities and Constraints

- 默认使用 React、TypeScript、Vite 和 pnpm。
- 根目录提供 `uxer.config.json`。
- React 根节点只接入一次 UXer Inspector。
- 默认不调用受保护业务后端，不使用 RAM、BUC 或 AMP Fetcher，也不配置开发代理。
- Publish 使用 `authProvider: "none"` 与空 routes，并必须支持 UXer 追加的 `--outDir` 和 `--base` 参数。
- 页面必须响应式、可访问，并保持容易替换和扩展。
- 应用内已准备 Alert、Button、Input 与 Switch，首页提供通知、表单和操作按钮的真实交互示例。

## Brand Commitments

产品名称为 Demo 应用模版。界面默认使用中文，产品名称、导航、状态、按钮和示例内容都以中文表达；React、Vite、Inspector、Demo、Publish 等技术专名保留原文。语气专业、清晰、有设计判断，不使用虚构客户、性能数据或商业宣传。

## Evidence on Hand

当前没有客户素材、品牌图片、指标、案例或外部数据。页面不得虚构这些证据；示例内容应明确属于模板自身或可交互演示。

## Product Principles

- 克隆后立即可运行，而不是只展示配置片段。
- 平台接入是工程默认值，不是使用者需要补做的教程。
- 首页服务于页面和应用设计，不向最终用户解释代理、认证或发布实现。
- 默认保持无认证、无代理、无业务后端依赖。
- 首屏本身体现可达到的设计质量，同时不过度绑定具体业务。
- 所有示例交互都应真实工作，并能成为扩展入口。
- 默认中文表达自然、简洁，不使用翻译腔或中英文装饰性混排。

## Accessibility & Inclusion

遵循语义化 HTML、键盘可操作、清晰焦点状态、充足色彩对比，并尊重减少动态效果的系统设置。
