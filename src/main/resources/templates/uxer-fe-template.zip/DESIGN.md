---
name: Demo 应用模版
description: 以纸面灰白、浅灰工作台与石墨动作色构成的现代中文组件体验界面。
colors:
  paper: "#f5f6f4"
  surface: "#ffffff"
  ink: "#171b18"
  muted: "#68706b"
  line: "#d2d7d3"
  neutral-stage: "#e8ebe7"
  graphite: "#2f3733"
  graphite-deep: "#202623"
  graphite-soft: "#e1e5e2"
  slate-blue: "#3f5f7a"
  indigo-ink: "#4f5579"
  clay-amber: "#9a541d"
  rose-ink: "#963d5c"
  success: "#276344"
  warning: "#8a5a13"
  error: "#a33b33"
  live-status: "#2cb45c"
typography:
  display:
    fontFamily: "'Noto Sans SC Variable', 'PingFang SC', sans-serif"
    fontSize: "clamp(3.25rem, 5.8vw, 5.5rem)"
    fontWeight: 610
    lineHeight: 1.08
    letterSpacing: "-0.035em"
  headline:
    fontFamily: "'Noto Sans SC Variable', 'PingFang SC', sans-serif"
    fontSize: "clamp(2rem, 3.5vw, 3.65rem)"
    fontWeight: 590
    lineHeight: 1.15
    letterSpacing: "-0.025em"
  title:
    fontFamily: "'Noto Sans SC Variable', 'PingFang SC', sans-serif"
    fontSize: "19px"
    fontWeight: 650
    lineHeight: 1.4
  body:
    fontFamily: "'Noto Sans SC Variable', 'PingFang SC', sans-serif"
    fontSize: "15px"
    fontWeight: 400
    lineHeight: 1.7
  label:
    fontFamily: "'Noto Sans SC Variable', 'PingFang SC', sans-serif"
    fontSize: "13px"
    fontWeight: 560
    lineHeight: 1.5
rounded:
  hairline: "1px"
  chart: "3px"
  compact: "4px"
  badge: "5px"
  control: "6px"
  button: "7px"
  panel: "8px"
  mobile-stage: "10px"
  stage: "12px"
  pill: "999px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "24px"
  xl: "32px"
  section: "64px"
components:
  button-primary:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.surface}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "0 22px"
    height: "48px"
  button-primary-hover:
    backgroundColor: "{colors.graphite-deep}"
    textColor: "{colors.surface}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "0 22px"
    height: "48px"
  button-secondary:
    backgroundColor: transparent
    textColor: "{colors.ink}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "0 22px"
    height: "48px"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.control}"
    padding: "0 16px"
    height: "54px"
  tab-selected:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.surface}"
    typography: "{typography.label}"
    rounded: "{rounded.control}"
    padding: "0 17px"
    height: "38px"
  switch-on:
    backgroundColor: "{colors.graphite}"
    textColor: "{colors.surface}"
    rounded: "{rounded.pill}"
    width: "40px"
    height: "23px"
  playground-stage:
    backgroundColor: "{colors.neutral-stage}"
    textColor: "{colors.ink}"
    rounded: "{rounded.stage}"
  theme-trigger:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    typography: "{typography.label}"
    rounded: "{rounded.button}"
    padding: "0 12px"
    height: "38px"
  theme-panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    typography: "{typography.label}"
    rounded: "{rounded.panel}"
    padding: "18px"
    width: "372px"
---

# Design System: Demo 应用模版

## Overview

**Creative North Star: "安静的石墨工作台"**

这个系统以产品操作为中心：纸面灰白提供安静基底，石墨色明确主要动作和当前位置，单一浅灰工作台承载真实 React 组件。视觉证明来自可操作状态、清晰层级和精确间距，而不是高彩度品牌色、插画或虚构数据。

Demo 应用模版以首页、组件体验和表单三个独立页面承载发现、试用与完整填写流程；统一页头固定导航顺序，并在右上角提供主题选择。界面保持现代中文产品的克制与可信，保留模板的真实内容、行为和工程边界，但不借用嵌套工作台、浏览器窗口或假截图来表达能力。

**Key Characteristics:**

- 大尺度中文无衬线标题、低密度导航和充足留白。
- 默认以石墨表达主操作与当前状态，并允许切换低饱和强调色。
- 单一浅灰工作台承载通知、表单、按钮和实时预览。
- 首页展示 3 个常用组件入口，使用“已准备好”的产品语言。
- 普通控件使用 6–8px 几何圆角，按钮固定为 7px。
- 胶囊只用于 Switch 轨道和天然圆形状态点。
- 状态色只表达语义，并始终配合文字或图标。

## Colors

调色板由温和近白、低色度灰绿中性色和深石墨构成；它依靠明度而不是色相建立层级。

### Primary

- **石墨动作色** (`graphite`)：默认主题；用于主按钮、选中标签、开启的 Switch、焦点轮廓和品牌标记。
- **岩层蓝** (`slate-blue`)、**靛墨** (`indigo-ink`)、**陶土琥珀** (`clay-amber`) 与 **玫瑰墨** (`rose-ink`)：低饱和预设主题，只替换单一强调色及其配套浅色舞台。
- **深石墨悬停色** (`graphite-deep`)：默认主题的悬停色；其它主题从当前强调色推导同等层级的深色反馈。
- **自定义深色强调色：** 仅接受能让白色文字达到 WCAG 4.5:1 对比度的颜色；浅色舞台和弱状态底随强调色协调变化。

### Secondary

- **成功绿** (`success`)、**提醒赭色** (`warning`) 与 **错误红** (`error`)：分别表达成功、提醒和失败反馈。
- **状态绿** (`live-status`)：仅用于页面可继续编辑等明确状态点。

### Neutral

- **纸面灰白** (`paper`)：页面底色，提供低眩光的阅读环境。
- **纯白表面** (`surface`)：组件清单、体验区内层和预览画布。
- **浅灰工作台** (`neutral-stage`)：大面积组件体验舞台，不扩散成满页卡片墙。
- **墨色** (`ink`)：标题和正文主文字。
- **次级文字** (`muted`)：说明、帮助文字和弱元数据。
- **低对比分隔线** (`line`)：控件边界、分栏和结构分隔。
- **石墨弱底** (`graphite-soft`)：图标底、计数和轻量选中提示。

**The One Active Accent Rule.** 石墨是默认强调色；无论选择预设还是自定义主题，同一时刻只能有一个强调色负责主要动作、焦点和当前状态。

**The Accessible Accent Rule.** 自定义强调色必须让白色文字达到至少 4.5:1 的对比度；不满足时保留输入反馈但不应用主题。

**The Semantic Color Rule.** 绿、赭、红只表达明确状态，不能承担品牌、导航或装饰职责，也不能脱离文字单独传意。

## Typography

**Display Font:** Noto Sans SC Variable（回退至 PingFang SC 与系统无衬线）

**Body Font:** Noto Sans SC Variable（回退至 PingFang SC 与系统无衬线）

**Character:** 字体克制、现代、直接。层级来自字号、字重、行宽和留白，不使用装饰性中英混排。

### Hierarchy

- **Display**（610，响应式大字号，行高 1.08）：只用于首屏主张和预览中的主标题；让中文自然换行，不手工断句。
- **Headline**（590，响应式区块字号，行高 1.15）：用于一级体验区标题。
- **Title**（650，19px，行高 1.4）：用于组件标题、空状态标题和能力名称。
- **Body**（400，15px，行高 1.7）：用于说明与连续阅读，正文宽度保持约 34–65 个中文字符。
- **Label**（560，13px，行高 1.5）：用于导航、字段、按钮、标签和状态。

**The Natural Chinese Rule.** 默认文案使用自然、简洁的中文；React、Vite、Inspector、Demo 与 Publish 等技术专名按产品事实保留，但不作为装饰。

## Layout

桌面页头和首屏使用最大 1440px 的居中容器，页面两侧至少留 32px；浅灰工作台放宽至最大 1536px，成为比正文更宽的产品展示面。页头由左侧 Demo 应用模版品牌、居中导航和右侧主题选择器组成；导航顺序固定为“首页 → 组件体验 → 表单”，当前页面清晰标记。首页首屏使用左宽右窄的双栏，工作台在 1280×720 的首屏内至少露出标题和真实表面。

首页负责产品主张和 3 个常用组件入口；组件体验页承载通知、表单控件和操作按钮的即时交互；表单页把同一套组件组合成可填写、校验和提交的完整前端示例。工作台内部先横向排列标题与分段切换器，再用单一白色表面承载内容。

- **宽于 980px：** 保留首屏双栏和体验区双栏。
- **980px 及以下：** 首屏、体验区和表单内容改为单列，控制区位于预览上方。
- **680px 及以下：** 页面边距缩至 16px，导航在页头第二行保持可见，主题触发器收为图标，主题预设改为单列；操作纵向堆叠，工作台横向铺满并只保留顶部圆角。
- 移动端不得横向溢出；标题自然换行，不用固定高度裁切，三页导航和主题入口始终可到达。

**The Fixed Route Order Rule.** 桌面和移动端都保持“首页 → 组件体验 → 表单”，不能因重排或折行改变信息顺序。

**The Single Stage Rule.** 浅灰只建立一个主要工作台层级；不要把每个内容区都包装成独立灰色卡片。

## Elevation & Depth

系统以平面和色块分层为主。组件清单、字段和控制组依靠 1px 低对比边框组织结构；普通表面不使用阴影。体验区白色大表面使用一层宽而轻的环境阴影，主按钮使用低而紧的石墨阴影，以区分可操作层级而不制造漂浮卡片墙。

### Shadow Vocabulary

- **工作台表面：** `0 18px 48px rgba(39, 46, 42, 0.08)`，仅用于浅灰舞台中的白色体验表面。
- **主按钮静止：** `0 8px 22px rgba(47, 55, 51, 0.16)`，提供轻微可按压感。
- **主按钮悬停：** `0 10px 28px rgba(47, 55, 51, 0.20)`，与最多 2px 的上移共同反馈悬停。

工作台首次进入使用 760ms 的轻微上移与裁切展开；常规状态过渡为 160–180ms。系统设置减少动态效果时，滚动、动画和过渡必须近乎即时。

**The Flat-by-Default Rule.** 表面静止时保持平面；只有工作台主表面和主要动作可以获得阴影，状态反馈不靠堆叠更多阴影。

## Shapes

形状语言是紧凑、几何和低装饰。字段、选项、提示、图标底与预览内容使用 6px 圆角；按钮使用 7px；普通面板使用 8px；浅灰工作台使用 12px，移动端顶部圆角收为 10px。边框保持 1px 与低对比。

胶囊形只属于 Switch 轨道和状态点等天然圆形控件。按钮、输入框、分段切换器、标签和普通面板都不得扩展为大圆角或胶囊。

**The Geometric Radius Rule.** 普通控件保持 6–8px，按钮固定 7px，主工作台才使用 12px；半径随层级增加而不是随意变化。

## Components

### Buttons

- **Shape:** 紧凑几何圆角（7px），默认最小高度 48px，左右内边距 22px。
- **Primary:** 石墨底、白字与轻量石墨阴影；用于每个场景唯一的主要动作。
- **Secondary:** 透明底、墨色文字与 1px 内描边；悬停变为白色表面。
- **Quiet:** 无边框和无阴影；悬停仅使用石墨弱底。
- **Hover / Focus:** 悬停最多上移 2px；键盘焦点使用 3px 石墨轮廓和 3px 外偏移；按下回到基线。
- **Loading / Disabled:** 保留原生 `disabled`，同时降低明度并给出可见文字或加载指示。

### Inputs / Fields

- **Style:** 白色底、1px 低对比边框、6px 圆角、高度 54px；标签始终可见，帮助文字位于字段下方。
- **Focus:** 边框切换为石墨色，并出现 4px 半透明中性光环。
- **Content:** 用户输入的名称与内容保持原样，不做翻译或装饰性改写。

### Navigation

全局页头固定为左侧 Demo 应用模版品牌、居中“首页 → 组件体验 → 表单”、右侧主题选择器。当前页面使用可感知的文字状态，不显示额外就绪状态。移动端导航换到第二行而不是隐藏，主题入口保留图标。体验区使用语义化标签页；选中标签为当前强调色底白字，未选中标签透明且只在悬停时出现弱底。

### Theme Picker

主题选择器位于页头右上角，默认选择石墨灰。面板提供岩层蓝、靛墨、陶土琥珀和玫瑰墨等低饱和预设，以及自定义十六进制强调色；只有与白色文字达到 WCAG 4.5:1 对比度的深色才可应用。触发器、面板、预设和输入保持 6–8px 紧凑圆角，当前主题同时通过名称、色点和选择状态表达；主题变化须有可感知反馈。

### Alerts

提示使用 6px 圆角、低对比描边和同色系浅底。信息态保持石墨中性；成功、提醒、错误分别使用语义绿、赭、红，标题、图标和底色共同表达。提醒与错误使用 `alert`，信息与成功使用 `status`，关闭后焦点返回触发器。

### Switch

Switch 是系统唯一的胶囊控件：40×23px 轨道、17px 白色圆形滑块。关闭态为中灰，开启态为石墨；标签和描述始终在轨道外可见。

### Cards / Containers

首页的 3 个常用组件入口和预览容器使用白色或半透明白色表面、6–8px 圆角与低对比边框。统一使用“常用组件”和“已准备好”，不恢复旧组件称谓。浅灰工作台是唯一 12px 大舞台；内部保持一块主要白色表面，避免卡片嵌套。

### Page Type Preview

产品介绍页、数据看板与内容工作台必须切换整套结构，而不是只替换类型文字。预览复用相同的低色度色阶、紧凑圆角、当前强调色和语义状态色；所有数值与内容明确属于模板示例。

## Do's and Don'ts

### Do

- **Do** 保持左侧产品主张、右侧常用组件清单、下方浅灰工作台的批准构图。
- **Do** 保持“首页 → 组件体验 → 表单”的固定导航顺序，并在移动端保持三项可达。
- **Do** 让核心示例由真实 React 状态和语义控件驱动，并提供键盘与屏幕阅读器反馈。
- **Do** 默认使用石墨表达主操作与当前状态；其它主题保持单一、低饱和且满足白字对比度要求。
- **Do** 使用“常用组件”和“已准备好”，首页组件数量固定为 3。
- **Do** 保持首页专注组件体验，使用真实组件、真实状态和简洁中文。
- **Do** 在 320px 起的宽度保留可用性、焦点可见性和减少动态效果支持。

### Don't

- **Don't** 恢复旧的薄荷绿／紫色世界，或让多个强调色在同一主题中竞争。
- **Don't** 恢复嵌套 UXer 工作台、浏览器窗口、假截图或“截图中的截图”。
- **Don't** 把浅灰工作台替换成静态海报、插画或不可操作的视觉占位。
- **Don't** 引入卡片墙、渐变、强玻璃拟态、重阴影或让表面成排漂浮。
- **Don't** 把按钮、分段控件、输入框和普通面板做成大圆角或胶囊形。
- **Don't** 让状态只靠红绿颜色表达，也不要虚构客户、指标、价格或业务能力。
- **Don't** 显示额外就绪状态，不要恢复旧组件称谓，也不要把首页组件数量写成非 3。
- **Don't** 接受与白色文字对比度低于 4.5:1 的自定义强调色。
- **Don't** 添加无结果的主按钮、伪网络状态、业务代理或认证入口。
