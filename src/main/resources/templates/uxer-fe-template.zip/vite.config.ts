import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { autowonderCollaboration } from './vite-plugins/autowonder.ts';

const port = Number(process.env.PORT ?? 5173);

export default defineConfig(() => {
  return {
    plugins: [react(), autowonderCollaboration()],
    server: {
      host: '0.0.0.0',
      port,
      strictPort: true,
    },
  };
});
