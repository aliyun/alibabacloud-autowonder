import assert from 'node:assert/strict';
import { test } from 'node:test';
import { build, resolveConfig } from 'vite';

test('协作开发启用iframe通信并让Vite自动处理端口冲突', async () => {
  const config = await resolveConfig({ mode: 'autowonder' }, 'serve');
  assert.equal(config.server.strictPort, false);
  assert.equal(config.server.port, Number(process.env.PORT ?? 5173));
});

test('普通开发和构建使用固定端口', async () => {
  for (const [command, mode] of [['serve', 'development'], ['build', 'production']]) {
    const config = await resolveConfig({ mode }, command);
    assert.equal(config.server.strictPort, true);
  }
});

test('交付构建包含 Universal Inspector', async () => {
  const result = await build({ logLevel: 'silent', build: { write: false } });
  const outputs = Array.isArray(result) ? result : [result];
  const modules = outputs.flatMap(({ output }) => output
    .filter(asset => asset.type === 'chunk')
    .flatMap(chunk => Object.keys(chunk.modules)));
  assert.ok(modules.some(id => id.includes('/@uxerjs/universal-inspector/')));
  assert.ok(modules.every(id => !id.includes('/@ali/uxer-inspector/')));
});
