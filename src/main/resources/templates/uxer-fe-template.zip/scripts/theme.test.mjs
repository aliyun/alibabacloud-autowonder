import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  applyThemeColors,
  isAccessibleAccent,
  isHexColor,
  readStoredTheme,
  resolveThemeColors,
  themeLabel,
  themePresets,
} from '../src/theme/themes.ts';

test('主题方案给出强调色与舞台色', () => {
  for (const preset of themePresets) {
    assert.equal(isHexColor(preset.accent), true);
    assert.equal(isHexColor(preset.stage), true);
  }
  assert.equal(resolveThemeColors({ mode: 'preset', id: 'graphite' }).accent, '#111111');
});

test('自定义主题按色相推导舞台底色', () => {
  const colors = resolveThemeColors({ mode: 'custom', accent: '#ff8a00' });
  assert.equal(colors.accent, '#ff8a00');
  assert.match(colors.stage, /^#[0-9a-f]{6}$/);
  assert.equal(isHexColor(colors.stageStrong), true);
  const blue = resolveThemeColors({ mode: 'custom', accent: '#1e3a8a' });
  assert.ok(colors.stage > blue.stage, '暖色舞台应比冷色更亮或相当');
});

test('自定义强调色必须保证白色文字对比度', () => {
  assert.equal(isAccessibleAccent('#111111'), true);
  assert.equal(isAccessibleAccent('#ffffff'), false);
  assert.equal(isAccessibleAccent('#f5f6f4'), false);
  assert.equal(isAccessibleAccent('not-a-color'), false);
  for (const preset of themePresets) assert.equal(isAccessibleAccent(preset.accent), true);
});

test('历史存储的浅色自定义主题回退默认主题', () => {
  const originalWindow = globalThis.window;
  globalThis.window = {
    localStorage: {
      getItem: () => JSON.stringify({ mode: 'custom', accent: '#ffffff' }),
    },
  };
  try {
    assert.equal(readStoredTheme(), null);
  } finally {
    if (originalWindow === undefined) delete globalThis.window;
    else globalThis.window = originalWindow;
  }
});

test('未知预设回退默认主题，标签可读', () => {
  assert.equal(resolveThemeColors({ mode: 'preset', id: 'nope' }).accent, themePresets[0].accent);
  assert.equal(themeLabel({ mode: 'preset', id: 'slate-blue' }), '岩层蓝');
  assert.equal(themeLabel({ mode: 'custom', accent: '#ABCDEF' }), '自定义 #ABCDEF');
});

test('applyThemeColors 写入 CSS 变量', () => {
  const styles = new Map();
  const root = { style: { setProperty: (k, v) => styles.set(k, v) } };
  applyThemeColors({ mode: 'preset', id: 'graphite' }, root);
  assert.equal(styles.get('--accent'), '#111111');
  assert.equal(styles.get('--stage'), '#f0f0ed');
  assert.equal(styles.get('--stage-strong'), '#e4e4df');
});
