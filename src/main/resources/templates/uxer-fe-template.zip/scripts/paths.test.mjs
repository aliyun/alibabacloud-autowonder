import assert from 'node:assert/strict';
import { test } from 'node:test';
import { componentsPath, joinBase, navRoutes, resolveRoute, routeLabelFor, stripBase } from '../src/router/paths.ts';

const base = '/design-preview/auto-demo';

test('业务路由与预览 base 拼接', () => {
  assert.equal(joinBase('/', ''), '/');
  assert.equal(joinBase('/form', ''), '/form');
  assert.equal(joinBase('/', base), base);
  assert.equal(joinBase('/form', base), `${base}/form`);
});

test('浏览器路径还原为业务路由', () => {
  assert.equal(stripBase(base, base), '/');
  assert.equal(stripBase(`${base}/`, base), '/');
  assert.equal(stripBase(`${base}/form`, base), '/form');
  assert.equal(stripBase(`${base}/nope`, base), '/nope');
  assert.equal(stripBase('/form', ''), '/form');
});

test('拼接与还原互为逆运算', () => {
  for (const route of ['/', '/form', '/components', '/components/actions', '/nope']) {
    assert.equal(stripBase(joinBase(route, base), base), route);
  }
});

test('业务路径解析为路由视图', () => {
  assert.deepEqual(resolveRoute('/'), { kind: 'home' });
  assert.deepEqual(resolveRoute('/form'), { kind: 'form' });
  assert.deepEqual(resolveRoute('/components'), { kind: 'components', tab: 'form' });
  assert.deepEqual(resolveRoute('/components/form'), { kind: 'components', tab: 'form' });
  assert.deepEqual(resolveRoute('/components/actions'), { kind: 'components', tab: 'actions' });
  assert.deepEqual(resolveRoute('/nope'), { kind: 'not-found' });
  assert.deepEqual(resolveRoute('/components/unknown'), { kind: 'not-found' });
  assert.deepEqual(resolveRoute('/components/form/extra'), { kind: 'not-found' });
});

test('组件体验地址对默认页签使用干净路径', () => {
  assert.equal(componentsPath(), '/components');
  assert.equal(componentsPath('alert'), '/components/alert');
  assert.equal(componentsPath('form'), '/components');
  for (const tab of ['alert', 'form', 'actions']) {
    assert.equal(resolveRoute(componentsPath(tab)).kind, 'components');
  }
});

test('路由标题与页签解析保持一致', () => {
  assert.equal(routeLabelFor('/'), '首页');
  assert.equal(routeLabelFor('/components/form'), '组件体验');
  assert.equal(routeLabelFor('/form'), '新建页面申请');
  assert.equal(routeLabelFor('/nope'), '页面不存在');
});

test('导航顺序把表单放在第三个模块', () => {
  assert.deepEqual(navRoutes.map(({ label }) => label), ['首页', '组件体验', '表单示例']);
  assert.deepEqual(navRoutes.map(({ path }) => path), ['/', '/components', '/form']);
  for (const { kind, path } of navRoutes) {
    assert.equal(resolveRoute(path).kind, kind);
  }
});
