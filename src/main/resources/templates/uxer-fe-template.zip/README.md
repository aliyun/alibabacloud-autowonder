# AutoWonder PRD Starter

This React and Vite project provides example routes, themes, and components for
a prototype. Run `pnpm install --frozen-lockfile` and `pnpm dev` to open it locally.
For an AutoWonder work item, run `pnpm dev:autowonder` in the design checkout.
The collaboration mode uses the public Inspector and supports element selection,
navigation, and hot updates. The execution runtime supplies the preview base
path and reads the bound port when starting the preview.
