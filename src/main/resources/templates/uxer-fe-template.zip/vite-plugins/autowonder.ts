import type { Plugin } from 'vite';

/** 将平台协作配置集中在开发插件中，应用配置只需注册插件。 */
export function autowonderCollaboration(): Plugin {
  return {
    name: 'autowonder:collaboration',
    apply: (_config, { command, mode }) => command === 'serve' && mode === 'autowonder',
    config: () => ({
      server: { strictPort: false },
    }),
  };
}
