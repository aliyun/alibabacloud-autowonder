import { useEffect, useRef, useState } from 'react';
import { Check, Palette, RotateCcw } from 'lucide-react';
import {
  defaultThemeSelection,
  isAccessibleAccent,
  isHexColor,
  resolveThemeColors,
  themePresets,
  type ThemeSelection,
} from '../theme/themes';
import { Button } from './ui/Button';

type ThemePickerProps = {
  onChange: (selection: ThemeSelection) => void;
  value: ThemeSelection;
};

export function ThemePicker({ onChange, value }: ThemePickerProps) {
  const [open, setOpen] = useState(false);
  const [draftHex, setDraftHex] = useState(() => resolveThemeColors(value).accent);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const activeId = value.mode === 'preset' ? value.id : 'custom';
  const activeName = value.mode === 'custom'
    ? `自定义 ${draftHex.toUpperCase()}`
    : themePresets.find((preset) => preset.id === value.id)?.name ?? themePresets[0].name;
  const hexFormatted = isHexColor(draftHex);
  const hexValid = isAccessibleAccent(draftHex);

  useEffect(() => {
    setDraftHex(resolveThemeColors(value).accent);
  }, [value]);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!wrapperRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setOpen(false);
        triggerRef.current?.focus();
      }
    };
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  return (
    <div className="theme-picker" ref={wrapperRef}>
      <button
        ref={triggerRef}
        className="theme-trigger"
        type="button"
        aria-expanded={open}
        aria-controls="theme-panel"
        onClick={() => setOpen((current) => !current)}
      >
        <Palette aria-hidden="true" size={16} />
        <span className="theme-trigger-name">{activeName}</span>
        <span
          className="theme-trigger-dot"
          style={{ background: resolveThemeColors(value).accent }}
          aria-hidden="true"
        />
      </button>

      {open ? (
        <div className="theme-panel" id="theme-panel" role="group" aria-label="主题色设置">
          <p className="theme-panel-title">主题色</p>
          <div className="theme-preset-grid">
            {themePresets.map((preset) => (
              <button
                key={preset.id}
                className="theme-preset"
                type="button"
                aria-pressed={activeId === preset.id}
                onClick={() => onChange({ mode: 'preset', id: preset.id })}
              >
                <span className="theme-preset-swatches" aria-hidden="true">
                  <span style={{ background: preset.stage }} />
                  <span style={{ background: preset.accent }} />
                </span>
                <span className="theme-preset-copy">
                  <strong>{preset.name}</strong>
                  <small>{preset.description}</small>
                </span>
                {activeId === preset.id ? <Check aria-hidden="true" size={15} /> : null}
              </button>
            ))}
          </div>

          <div className="theme-custom">
            <label className="theme-custom-label" htmlFor="theme-custom-hex">
              自定义强调色
            </label>
            <div className="theme-custom-row">
              <input
                className="theme-color-input"
                type="color"
                aria-label="主题色取色器"
                value={hexFormatted ? normalize(draftHex) : '#2f3733'}
                onChange={(event) => {
                  setDraftHex(event.target.value);
                  if (isAccessibleAccent(event.target.value)) onChange({ mode: 'custom', accent: event.target.value });
                }}
              />
              <input
                id="theme-custom-hex"
                className={`theme-hex-input${hexValid ? '' : ' is-invalid'}`}
                value={draftHex}
                spellCheck={false}
                aria-invalid={!hexValid}
                aria-describedby="theme-hex-help"
                onChange={(event) => {
                  const next = event.target.value;
                  setDraftHex(next);
                  if (isAccessibleAccent(next)) onChange({ mode: 'custom', accent: next });
                }}
              />
              <button
                className="theme-apply"
                type="button"
                disabled={!hexValid}
                onClick={() => onChange({ mode: 'custom', accent: draftHex })}
              >
                应用
              </button>
            </div>
            <p className="theme-hex-help" id="theme-hex-help">
              {hexValid
                ? '舞台底色与图标底色会随强调色自动推导。'
                : hexFormatted
                  ? '请选择更深的颜色，确保白色文字清晰可读。'
                  : '请输入 6 位十六进制颜色，例如 #2F3733。'}
            </p>
          </div>

          <div className="theme-panel-foot">
            <Button
              className="theme-reset"
              type="button"
              variant="quiet"
              disabled={activeId === defaultThemeSelection().id}
              onClick={() => onChange(defaultThemeSelection())}
            >
              <RotateCcw aria-hidden="true" size={15} />
              恢复默认主题
            </Button>
          </div>
        </div>
      ) : null}

      <p className="theme-live" role="status">已应用主题：{activeName}</p>
    </div>
  );
}

function normalize(value: string) {
  return value.trim().toLowerCase();
}
