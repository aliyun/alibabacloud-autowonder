import { motion, useReducedMotion } from 'motion/react';

type SwitchProps = {
  checked: boolean;
  description?: string;
  label: string;
  onCheckedChange: (checked: boolean) => void;
};

export function Switch({ checked, description, label, onCheckedChange }: SwitchProps) {
  const reduceMotion = useReducedMotion();

  return (
    <div className="ui-switch-row">
      <span>
        <strong>{label}</strong>
        {description ? <small>{description}</small> : null}
      </span>
      <button
        className="ui-switch"
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        onClick={() => onCheckedChange(!checked)}
      >
        <motion.span
          animate={{ x: checked ? 17 : 0 }}
          transition={reduceMotion ? { duration: 0.01 } : { type: 'spring', stiffness: 500, damping: 32 }}
        />
      </button>
    </div>
  );
}
