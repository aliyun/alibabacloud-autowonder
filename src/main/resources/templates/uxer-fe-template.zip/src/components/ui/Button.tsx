import { LoaderCircle } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import type { ButtonHTMLAttributes, ReactNode } from 'react';

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  loading?: boolean;
  variant?: 'primary' | 'secondary' | 'quiet';
};

export function Button({
  children,
  className = '',
  disabled,
  loading = false,
  variant = 'primary',
  ...props
}: ButtonProps) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.button
      className={`ui-button ui-button-${variant} ${className}`.trim()}
      disabled={disabled || loading}
      whileTap={reduceMotion || disabled || loading ? undefined : { scale: 0.97 }}
      {...props}
    >
      {loading ? <LoaderCircle className="ui-spin" aria-hidden="true" size={17} /> : null}
      {children}
    </motion.button>
  );
}
