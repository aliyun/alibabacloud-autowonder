import {
  AlertCircle,
  CheckCircle2,
  Info,
  TriangleAlert,
  X,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
  createContext,
  type HTMLAttributes,
  type ReactNode,
  type RefObject,
  useContext,
  useLayoutEffect,
  useMemo,
  useRef,
} from 'react';

export type AlertVariant = 'info' | 'success' | 'warning' | 'error';

type AlertContextValue = {
  close: () => void;
  variant: AlertVariant;
};

const AlertContext = createContext<AlertContextValue | null>(null);

const alertIcons = {
  info: Info,
  success: CheckCircle2,
  warning: TriangleAlert,
  error: AlertCircle,
} as const;

function useAlertContext() {
  const value = useContext(AlertContext);
  if (!value) throw new Error('Alert 子组件必须放在 Alert 内部使用。');
  return value;
}

type AlertProps = {
  children: ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  returnFocusRef?: RefObject<HTMLElement | null>;
  variant?: AlertVariant;
};

export function Alert({
  children,
  open,
  onOpenChange,
  returnFocusRef,
  variant = 'info',
}: AlertProps) {
  const reduceMotion = useReducedMotion();
  const surfaceRef = useRef<HTMLDivElement>(null);
  const context = useMemo(() => ({ close: () => onOpenChange(false), variant }), [onOpenChange, variant]);

  useLayoutEffect(() => {
    if (!open && surfaceRef.current?.contains(document.activeElement)) {
      returnFocusRef?.current?.focus({ preventScroll: true });
    }
  }, [open, returnFocusRef]);

  return (
    <AlertContext.Provider value={context}>
      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            ref={surfaceRef}
            className="ui-alert"
            data-variant={variant}
            role={variant === 'warning' || variant === 'error' ? 'alert' : 'status'}
            initial={{ opacity: 0, y: reduceMotion ? 0 : -8, scale: reduceMotion ? 1 : 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: reduceMotion ? 0 : -6, scale: reduceMotion ? 1 : 0.985 }}
            transition={{ duration: reduceMotion ? 0.01 : 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            {children}
          </motion.div>
        ) : null}
      </AnimatePresence>
    </AlertContext.Provider>
  );
}

export function AlertIcon() {
  const { variant } = useAlertContext();
  const Icon = alertIcons[variant];
  return <Icon className="ui-alert-icon" aria-hidden="true" size={19} strokeWidth={1.8} />;
}

export function AlertContent({ className = '', ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={`ui-alert-content ${className}`.trim()} {...props} />;
}

export function AlertTitle({ className = '', ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={`ui-alert-title ${className}`.trim()} {...props} />;
}

export function AlertDescription({ className = '', ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={`ui-alert-description ${className}`.trim()} {...props} />;
}

export function AlertClose() {
  const { close } = useAlertContext();
  return (
    <motion.button
      className="ui-alert-close"
      type="button"
      aria-label="关闭提示"
      onClick={close}
      whileTap={{ scale: 0.92 }}
    >
      <X aria-hidden="true" size={17} />
    </motion.button>
  );
}
