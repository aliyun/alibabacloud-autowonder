import type { InputHTMLAttributes } from 'react';

type InputProps = InputHTMLAttributes<HTMLInputElement> & {
  helper?: string;
  label: string;
};

export function Input({ helper, id, label, ...props }: InputProps) {
  const helperId = helper && id ? `${id}-helper` : undefined;

  return (
    <label className="ui-field" htmlFor={id}>
      <span className="ui-field-label">{label}</span>
      <input id={id} aria-describedby={helperId} {...props} />
      {helper ? <span className="ui-field-helper" id={helperId}>{helper}</span> : null}
    </label>
  );
}
