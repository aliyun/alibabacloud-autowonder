import {
  Activity,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Clock3,
  Command,
  LayoutDashboard,
  MoreHorizontal,
  PanelsTopLeft,
} from 'lucide-react';

export type PageType = '产品介绍页' | '数据看板' | '内容工作台';

type PageTypePreviewProps = {
  commentsEnabled: boolean;
  pageName: string;
  pageType: PageType;
};

function PreviewFooter({ commentsEnabled }: Pick<PageTypePreviewProps, 'commentsEnabled'>) {
  return (
    <div className="sample-footer">
      <span className="page-sample-status"><span aria-hidden="true" /> 页面可以继续编辑</span>
      <span>{commentsEnabled ? '评论已开启' : '评论已关闭'}</span>
    </div>
  );
}

function IntroPreview({ commentsEnabled, pageName }: Omit<PageTypePreviewProps, 'pageType'>) {
  return (
    <div className="page-sample intro-sample">
      <div className="sample-mark"><Command aria-hidden="true" size={20} /></div>
      <div className="sample-copy">
        <span className="page-sample-type">产品介绍页</span>
        <h3>{pageName || '未命名页面'}</h3>
        <p>{commentsEnabled ? '邀请协作者一起查看、评论并完善这个页面。' : '一个干净、可以继续扩展的页面起点。'}</p>
        <div className="sample-actions" aria-hidden="true"><span>查看内容</span><span>了解更多</span></div>
      </div>
      <PreviewFooter commentsEnabled={commentsEnabled} />
    </div>
  );
}

function DashboardPreview({ commentsEnabled, pageName }: Omit<PageTypePreviewProps, 'pageType'>) {
  return (
    <div className="page-sample dashboard-sample">
      <header className="preview-page-header">
        <span className="sample-mark"><LayoutDashboard aria-hidden="true" size={20} /></span>
        <span><strong>{pageName || '未命名看板'}</strong><small>数据看板 · 示例数据</small></span>
        <span className="preview-status-chip">本周</span>
      </header>

      <div className="dashboard-metrics" aria-label="示例指标">
        <div><span>本周访问</span><strong>12,480</strong><small><ArrowUpRight aria-hidden="true" size={13} /> 12.4%</small></div>
        <div><span>完成率</span><strong>84%</strong><small>较上周 +6%</small></div>
        <div><span>待处理</span><strong>18</strong><small>3 项优先</small></div>
      </div>

      <div className="dashboard-detail">
        <section className="dashboard-chart" aria-label="示例趋势">
          <div><strong>访问趋势</strong><span>最近 7 天</span></div>
          <div className="chart-bars" aria-hidden="true">
            <i /><i /><i /><i /><i /><i /><i />
          </div>
        </section>
        <section className="dashboard-summary">
          <span className="summary-icon"><Activity aria-hidden="true" size={18} /></span>
          <span><strong>运行平稳</strong><small>核心指标保持增长</small></span>
        </section>
      </div>
      <PreviewFooter commentsEnabled={commentsEnabled} />
    </div>
  );
}

function WorkbenchPreview({ commentsEnabled, pageName }: Omit<PageTypePreviewProps, 'pageType'>) {
  const tasks = [
    { label: '完善首页文案', status: '进行中', icon: Clock3 },
    { label: '确认组件状态', status: '待处理', icon: PanelsTopLeft },
    { label: '邀请成员评审', status: '已完成', icon: CheckCircle2 },
  ] as const;

  return (
    <div className="page-sample workbench-sample">
      <header className="preview-page-header">
        <span className="sample-mark"><PanelsTopLeft aria-hidden="true" size={20} /></span>
        <span><strong>{pageName || '未命名工作台'}</strong><small>内容工作台</small></span>
        <span className="preview-status-chip">3 项任务</span>
      </header>

      <div className="workbench-layout">
        <nav className="workbench-nav" aria-label="工作台示例导航">
          <span className="active"><LayoutDashboard aria-hidden="true" size={16} />概览</span>
          <span><Check aria-hidden="true" size={16} />任务</span>
          <span><Activity aria-hidden="true" size={16} />动态</span>
        </nav>
        <section className="workbench-content">
          <div className="workbench-toolbar"><span><strong>今日任务</strong><small>3 项工作</small></span><span>新建任务</span></div>
          <div className="task-list">
            {tasks.map(({ icon: Icon, label, status }) => (
              <div key={label}>
                <Icon aria-hidden="true" size={17} />
                <span><strong>{label}</strong><small>{status}</small></span>
                <MoreHorizontal aria-hidden="true" size={17} />
              </div>
            ))}
          </div>
        </section>
      </div>
      <PreviewFooter commentsEnabled={commentsEnabled} />
    </div>
  );
}

export function PageTypePreview(props: PageTypePreviewProps) {
  if (props.pageType === '数据看板') return <DashboardPreview {...props} />;
  if (props.pageType === '内容工作台') return <WorkbenchPreview {...props} />;
  return <IntroPreview {...props} />;
}
