import { useEffect, useState } from 'react';
import { ArrowRight, Compass } from 'lucide-react';
import { ThemePicker } from './components/ThemePicker';
import { ComponentsPage } from './pages/ComponentsPage';
import { FormPage } from './pages/FormPage';
import { HomePage } from './pages/HomePage';
import { Link, useRouter } from './router/router';
import { appPaths, navRoutes, resolveRoute, routeLabelFor } from './router/paths';
import {
  applyThemeColors,
  defaultThemeSelection,
  readStoredTheme,
  storeTheme,
  type ThemeSelection,
} from './theme/themes';

function NotFound({ path }: { path: string }) {
  return (
    <section className="not-found" aria-labelledby="not-found-title">
      <span className="not-found-icon"><Compass aria-hidden="true" size={22} /></span>
      <h1 id="not-found-title">这个地址还没有对应的页面</h1>
      <p>当前访问的是 <code>{path}</code>。表单页演示字段的填写与校验，组件体验页可以直接体验常用组件。</p>
      <div className="not-found-actions">
        <Link className="not-found-link" to={appPaths.home}><span>返回首页</span><ArrowRight aria-hidden="true" size={16} /></Link>
        <Link className="not-found-link" to={appPaths.form}><span>前往表单页</span><ArrowRight aria-hidden="true" size={16} /></Link>
        <Link className="not-found-link" to={appPaths.components}><span>前往组件体验</span><ArrowRight aria-hidden="true" size={16} /></Link>
      </div>
    </section>
  );
}

function App() {
  const [theme, setTheme] = useState<ThemeSelection>(() => readStoredTheme() ?? defaultThemeSelection());
  const { path } = useRouter();
  const route = resolveRoute(path);

  useEffect(() => {
    applyThemeColors(theme);
    storeTheme(theme);
  }, [theme]);

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' });
  }, [path]);

  useEffect(() => {
    document.title = `Demo 应用模版 · ${routeLabelFor(path)}`;
  }, [path]);

  const navItems = navRoutes.map(({ kind, label, path: to }) => ({
    current: route.kind === kind,
    label,
    to,
  }));

  return (
    <div className="app-shell">
      <header className="site-header">
        <Link className="brand" to={appPaths.home} aria-label="Demo 应用模版首页">
          <span className="brand-mark" aria-hidden="true"><span /><span /><span /></span>
          <span>Demo 应用模版</span>
        </Link>
        <nav className="site-nav" aria-label="主导航">
          {navItems.map(({ current, label, to }) => (
            <Link key={to} to={to} aria-current={current ? 'page' : undefined}>{label}</Link>
          ))}
        </nav>
        <div className="header-tools">
          <ThemePicker value={theme} onChange={setTheme} />
        </div>
      </header>

      <main id="top">
        {route.kind === 'home' ? <HomePage /> : null}
        {route.kind === 'components' ? <ComponentsPage tab={route.tab} /> : null}
        {route.kind === 'form' ? <FormPage /> : null}
        {route.kind === 'not-found' ? <NotFound path={path} /> : null}
      </main>

      <footer className="site-footer">
        <span>Demo 应用模版</span>
        <span>常用组件已准备好，可以直接开始设计</span>
      </footer>
    </div>
  );
}

export default App;
