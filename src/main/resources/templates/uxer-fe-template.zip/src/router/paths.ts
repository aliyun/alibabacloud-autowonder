export const routeBasename: string = (import.meta.env?.BASE_URL ?? '/').replace(/\/+$/, '');

export const showcaseTabs = ['alert', 'form', 'actions'] as const;

export type ShowcaseTab = (typeof showcaseTabs)[number];

export const defaultShowcaseTab: ShowcaseTab = 'form';

export const appPaths = {
  components: '/components',
  form: '/form',
  home: '/',
} as const;

export type NavRoute = { kind: Route['kind']; label: string; path: string };

export const navRoutes: readonly NavRoute[] = [
  { kind: 'home', label: '首页', path: appPaths.home },
  { kind: 'components', label: '组件体验', path: appPaths.components },
  { kind: 'form', label: '表单示例', path: appPaths.form },
];

export type Route =
  | { kind: 'components'; tab: ShowcaseTab }
  | { kind: 'form' }
  | { kind: 'home' }
  | { kind: 'not-found' };

function isShowcaseTab(value?: string): value is ShowcaseTab {
  return value !== undefined && (showcaseTabs as readonly string[]).includes(value);
}

export function joinBase(path: string, base = routeBasename): string {
  const normalized = path === '/' ? '' : path.startsWith('/') ? path : `/${path}`;
  return `${base}${normalized}` || '/';
}

export function stripBase(pathname: string, base = routeBasename): string {
  const stripped = base && pathname.startsWith(base) ? pathname.slice(base.length) : pathname;
  if (stripped === '' || stripped === '/') return '/';
  return stripped.startsWith('/') ? stripped : `/${stripped}`;
}

export function componentsPath(tab: ShowcaseTab = defaultShowcaseTab): string {
  return tab === defaultShowcaseTab ? appPaths.components : `${appPaths.components}/${tab}`;
}

export function resolveRoute(path: string): Route {
  const [first, second, ...rest] = path.split('/').filter(Boolean);
  if (rest.length || (first === 'components' && second && !isShowcaseTab(second))) {
    return { kind: 'not-found' };
  }
  if (!first) return { kind: 'home' };
  if (first === 'form') return { kind: 'form' };
  if (first === 'components') {
    return { kind: 'components', tab: isShowcaseTab(second) ? second : defaultShowcaseTab };
  }
  return { kind: 'not-found' };
}

export function routeLabelFor(path: string): string {
  const route = resolveRoute(path);
  if (route.kind === 'home') return '首页';
  if (route.kind === 'form') return '新建页面申请';
  if (route.kind === 'components') return '组件体验';
  return '页面不存在';
}
