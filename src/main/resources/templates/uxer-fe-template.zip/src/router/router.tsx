import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type AnchorHTMLAttributes,
  type ReactNode,
} from 'react';

import { joinBase, stripBase } from './paths';

function readPath(): string {
  return stripBase(window.location.pathname);
}

type RouterValue = {
  navigate: (path: string, options?: { replace?: boolean }) => void;
  path: string;
};

const RouterContext = createContext<RouterValue | null>(null);

export function RouterProvider({ children }: { children: ReactNode }) {
  const [path, setPath] = useState(readPath);

  useEffect(() => {
    const onPopState = () => setPath(readPath());
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigate = useCallback((next: string, options?: { replace?: boolean }) => {
    if (next === readPath()) return;
    const method = options?.replace ? 'replaceState' : 'pushState';
    window.history[method]({ path: next }, '', joinBase(next));
    setPath(next);
  }, []);

  const value = useMemo(() => ({ navigate, path }), [navigate, path]);

  return <RouterContext.Provider value={value}>{children}</RouterContext.Provider>;
}

export function useRouter(): RouterValue {
  const context = useContext(RouterContext);
  if (!context) throw new Error('useRouter 必须在 RouterProvider 内使用');
  return context;
}

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & { to: string };

export function Link({ children, onClick, to, ...props }: LinkProps) {
  const { navigate } = useRouter();

  return (
    <a
      {...props}
      href={joinBase(to)}
      onClick={(event) => {
        onClick?.(event);
        if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.button !== 0) return;
        event.preventDefault();
        navigate(to);
      }}
    >
      {children}
    </a>
  );
}
