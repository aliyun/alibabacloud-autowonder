import { useRef, useState, type KeyboardEvent } from 'react';
import {
  ArrowRight,
  BellRing,
  CheckCircle2,
  FormInput,
  ChartNoAxesCombined,
  LayoutTemplate,
  MousePointerClick,
  PanelsTopLeft,
  RotateCcw,
  Send,
  SlidersHorizontal,
} from 'lucide-react';
import {
  Alert,
  AlertClose,
  AlertContent,
  AlertDescription,
  AlertIcon,
  AlertTitle,
  type AlertVariant,
} from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Switch } from '../components/ui/Switch';
import { PageTypePreview, type PageType } from '../components/PageTypePreview';
import { Link, useRouter } from '../router/router';
import { componentsPath, showcaseTabs, type ShowcaseTab } from '../router/paths';

const showcases: ReadonlyArray<{
  description: string;
  icon: typeof BellRing;
  id: ShowcaseTab;
  label: string;
}> = [
  { id: 'alert', label: '通知提示', description: '反馈、提醒和错误状态', icon: BellRing },
  { id: 'form', label: '表单控件', description: '输入、选择和开关', icon: FormInput },
  { id: 'actions', label: '操作按钮', description: '主次操作和加载状态', icon: MousePointerClick },
];

const alertCopy: Record<AlertVariant, { title: string; description: string }> = {
  info: { title: '页面会自动保存', description: '继续设计即可，你的修改会保留在当前页面中。' },
  success: { title: '内容已更新', description: '新的页面设置已经生效。' },
  warning: { title: '还有内容未填写', description: '补充页面名称后，就可以继续下一步。' },
  error: { title: '暂时无法保存', description: '检查必填内容后再试一次。' },
};

const alertVariants: ReadonlyArray<{ id: AlertVariant; label: string }> = [
  { id: 'info', label: '信息' },
  { id: 'success', label: '成功' },
  { id: 'warning', label: '提醒' },
  { id: 'error', label: '错误' },
];

const pageTypes: ReadonlyArray<{ id: PageType; label: string; icon: typeof LayoutTemplate }> = [
  { id: '产品介绍页', label: '介绍页', icon: LayoutTemplate },
  { id: '数据看板', label: '看板', icon: ChartNoAxesCombined },
  { id: '内容工作台', label: '工作台', icon: PanelsTopLeft },
] as const;

export function ComponentsPage({ tab }: { tab: ShowcaseTab }) {
  const { navigate } = useRouter();
  const [alertVariant, setAlertVariant] = useState<AlertVariant>('info');
  const [alertOpen, setAlertOpen] = useState(true);
  const [pageName, setPageName] = useState('我的新页面');
  const [pageType, setPageType] = useState<PageType>('产品介绍页');
  const [commentsEnabled, setCommentsEnabled] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionFeedback, setActionFeedback] = useState('');
  const showAlertRef = useRef<HTMLButtonElement>(null);

  const moveBetweenTabs = (event: KeyboardEvent<HTMLDivElement>) => {
    const currentIndex = showcaseTabs.indexOf(tab);
    let nextIndex = currentIndex;

    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') nextIndex = (currentIndex + 1) % showcaseTabs.length;
    if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') nextIndex = (currentIndex - 1 + showcaseTabs.length) % showcaseTabs.length;
    if (event.key === 'Home') nextIndex = 0;
    if (event.key === 'End') nextIndex = showcaseTabs.length - 1;
    if (nextIndex === currentIndex) return;

    event.preventDefault();
    const nextTab = showcaseTabs[nextIndex];
    navigate(componentsPath(nextTab));
    document.getElementById(`showcase-tab-${nextTab}`)?.focus();
  };

  const runAction = () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setActionFeedback('');
    window.setTimeout(() => {
      setIsSubmitting(false);
      setActionFeedback('操作已完成。');
    }, 700);
  };

  return (
    <section className="components-page">
      <section className="component-stage" id="components" aria-labelledby="components-title">
        <div className="stage-heading">
          <div>
            <h1 id="components-title">常用组件体验区</h1>
            <p>选择一个组件，切换状态并直接操作。这里看到的，就是应用中已经准备好的组件。</p>
          </div>
          <div className="showcase-tabs" role="tablist" aria-label="组件类型" onKeyDown={moveBetweenTabs}>
            {showcases.map(({ id, label }) => (
              <Link
                key={id}
                id={`showcase-tab-${id}`}
                className="showcase-tab"
                role="tab"
                to={componentsPath(id)}
                aria-selected={tab === id}
                aria-controls={`showcase-panel-${id}`}
                tabIndex={tab === id ? 0 : -1}
              >
                {label}
              </Link>
            ))}
          </div>
        </div>

        <div className="showcase-surface">
          {tab === 'alert' ? (
            <div className="showcase-layout" id="showcase-panel-alert" role="tabpanel" aria-labelledby="showcase-tab-alert">
              <div className="showcase-controls">
                <div className="control-heading">
                  <span className="control-icon"><BellRing aria-hidden="true" size={20} /></span>
                  <span><h3>通知提示</h3><p>适合保存反馈、提醒和错误恢复。</p></span>
                </div>
                <fieldset className="variant-picker">
                  <legend>提示类型</legend>
                  <div>
                    {alertVariants.map(({ id, label }) => (
                      <button
                        key={id}
                        type="button"
                        aria-pressed={alertVariant === id}
                        onClick={() => {
                          setAlertVariant(id);
                          setAlertOpen(true);
                        }}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </fieldset>
                <button
                  ref={showAlertRef}
                  className="ui-button ui-button-secondary show-alert-button"
                  type="button"
                  disabled={alertOpen}
                  onClick={() => setAlertOpen(true)}
                >
                  <RotateCcw aria-hidden="true" size={16} />
                  {alertOpen ? '提示正在显示' : '重新显示提示'}
                </button>
              </div>

              <div className="component-preview alert-preview">
                <span className="preview-label">组件预览</span>
                <div className="alert-slot">
                  <Alert
                    open={alertOpen}
                    onOpenChange={setAlertOpen}
                    returnFocusRef={showAlertRef}
                    variant={alertVariant}
                  >
                    <AlertIcon />
                    <AlertContent>
                      <AlertTitle>{alertCopy[alertVariant].title}</AlertTitle>
                      <AlertDescription>{alertCopy[alertVariant].description}</AlertDescription>
                    </AlertContent>
                    <AlertClose />
                  </Alert>
                  {!alertOpen ? (
                    <button className="empty-alert" type="button" onClick={() => setAlertOpen(true)}>
                      提示已关闭，点击重新显示
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
          ) : null}

          {tab === 'form' ? (
            <div className="showcase-layout" id="showcase-panel-form" role="tabpanel" aria-labelledby="showcase-tab-form">
              <div className="showcase-controls">
                <div className="control-heading">
                  <span className="control-icon"><SlidersHorizontal aria-hidden="true" size={20} /></span>
                  <span><h3>表单控件</h3><p>字段变化会立即反映在右侧。</p></span>
                </div>
                <Input
                  id="page-name"
                  label="页面名称"
                  value={pageName}
                  onChange={(event) => setPageName(event.target.value)}
                  helper="使用清楚、容易识别的名称。"
                />
                <fieldset className="page-type-picker">
                  <legend>页面类型</legend>
                  <div>
                    {pageTypes.map(({ icon: Icon, id, label }) => (
                      <button
                        key={id}
                        type="button"
                        aria-pressed={pageType === id}
                        onClick={() => setPageType(id)}
                      >
                        <Icon aria-hidden="true" size={19} strokeWidth={1.7} />
                        <span>{label}</span>
                      </button>
                    ))}
                  </div>
                </fieldset>
                <Switch
                  checked={commentsEnabled}
                  onCheckedChange={setCommentsEnabled}
                  label="允许设计评论"
                  description="协作者可以在页面上留下建议。"
                />
              </div>

              <div className="component-preview form-preview" aria-live="polite">
                <div className="canvas-toolbar">
                  <span className="preview-label">页面预览</span>
                  <span>{commentsEnabled ? '可评论' : '仅浏览'}</span>
                </div>
                <PageTypePreview pageName={pageName} pageType={pageType} commentsEnabled={commentsEnabled} />
              </div>
            </div>
          ) : null}

          {tab === 'actions' ? (
            <div className="showcase-layout" id="showcase-panel-actions" role="tabpanel" aria-labelledby="showcase-tab-actions">
              <div className="showcase-controls">
                <div className="control-heading">
                  <span className="control-icon"><MousePointerClick aria-hidden="true" size={20} /></span>
                  <span><h3>操作按钮</h3><p>主次层级、禁用和加载状态都已准备好。</p></span>
                </div>
                <div className="button-stack">
                  <Button type="button" loading={isSubmitting} onClick={runAction}>
                    {isSubmitting ? '正在保存' : '保存页面'}
                  </Button>
                  <Button type="button" variant="secondary" onClick={() => setActionFeedback('已打开预览。')}>
                    预览页面
                  </Button>
                  <Button type="button" variant="quiet" onClick={() => setActionFeedback('操作已取消。')}>
                    取消
                  </Button>
                </div>
                <p className="action-feedback" role="status">{actionFeedback}</p>
              </div>

              <div className="component-preview actions-preview">
                <span className="preview-label">组合示例</span>
                <div className="action-composition">
                  <span className="composition-icon"><Send aria-hidden="true" size={24} /></span>
                  <h3>发布这次设计？</h3>
                  <p>检查页面内容，然后选择下一步操作。</p>
                  <div>
                    <Button type="button" variant="secondary" onClick={() => setActionFeedback('已返回编辑。')}>返回编辑</Button>
                    <Button type="button" onClick={() => setActionFeedback('设计已发布。')}>确认发布</Button>
                  </div>
                  {actionFeedback ? <span className="composition-feedback"><CheckCircle2 aria-hidden="true" size={16} />{actionFeedback}</span> : null}
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </section>

      <p className="stage-note">
        这些组件已经组成了一个可填写的表单，可以在
        <Link className="stage-note-link" to="/form"><span>新建页面申请</span><ArrowRight aria-hidden="true" size={15} /></Link>
        里看到完整效果，或
        <Link className="stage-note-link" to="/"><span>返回首页</span><ArrowRight aria-hidden="true" size={15} /></Link>
        。
      </p>
    </section>
  );
}
