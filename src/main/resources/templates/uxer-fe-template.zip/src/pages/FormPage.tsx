import { useRef, useState } from 'react';
import { ArrowLeft, CircleAlert, LoaderCircle, Send } from 'lucide-react';
import {
  Alert,
  AlertClose,
  AlertContent,
  AlertDescription,
  AlertIcon,
  AlertTitle,
  type AlertVariant,
} from '../components/ui/Alert';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Switch } from '../components/ui/Switch';
import { Link } from '../router/router';

type FormValues = {
  name: string;
  owner: string;
  releaseDate: string;
  kind: '产品介绍页' | '数据看板' | '内容工作台';
  commentsEnabled: boolean;
  notifyOwner: boolean;
};

type FieldErrors = Partial<Record<'name' | 'owner' | 'releaseDate', string>>;

const initialValues: FormValues = {
  name: '',
  owner: '',
  releaseDate: '',
  kind: '产品介绍页',
  commentsEnabled: true,
  notifyOwner: false,
};

const kindOptions = [
  { id: '产品介绍页', label: '介绍页' },
  { id: '数据看板', label: '看板' },
  { id: '内容工作台', label: '工作台' },
] as const;

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values: FormValues): FieldErrors {
  const errors: FieldErrors = {};
  const name = values.name.trim();
  if (name.length === 0) errors.name = '请填写页面名称。';
  else if (name.length < 2) errors.name = '页面名称至少 2 个字符。';
  else if (name.length > 40) errors.name = '页面名称不超过 40 个字符。';

  const owner = values.owner.trim();
  if (owner.length === 0) errors.owner = '请填写负责人邮箱，方便回收结果。';
  else if (!emailPattern.test(owner)) errors.owner = '邮箱格式不正确，例如 designer@example.com。';

  if (values.releaseDate) {
    const picked = new Date(`${values.releaseDate}T00:00:00`);
    if (Number.isNaN(picked.getTime())) errors.releaseDate = '日期格式不正确。';
    else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (picked < today) errors.releaseDate = '上线日期不能早于今天。';
    }
  }
  return errors;
}

export function FormPage() {
  const [values, setValues] = useState<FormValues>(initialValues);
  const [touched, setTouched] = useState<Partial<Record<keyof FieldErrors, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [receipt, setReceipt] = useState<string | null>(null);
  const [resultOpen, setResultOpen] = useState(false);
  const submitRef = useRef<HTMLButtonElement>(null);

  const errors = validate(values);
  const errorKeys = (['name', 'owner', 'releaseDate'] as const).filter((key) => errors[key]);
  const visibleError = (key: keyof FieldErrors) =>
    touched[key] || submitted ? errors[key] : undefined;

  const setValue = <K extends keyof FormValues>(key: K, value: FormValues[K]) => {
    setValues((current) => ({ ...current, [key]: value }));
    if (status === 'success') {
      setStatus('idle');
      setResultOpen(false);
    }
  };

  const markTouched = (key: keyof FieldErrors) => setTouched((current) => ({ ...current, [key]: true }));

  const resetForm = () => {
    setValues(initialValues);
    setTouched({});
    setSubmitted(false);
    setStatus('idle');
    setReceipt(null);
    setResultOpen(false);
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
    if (errorKeys.length > 0) {
      setResultOpen(false);
      document.getElementById(`form-field-${errorKeys[0]}`)?.focus();
      return;
    }
    setResultOpen(true);
    setStatus('submitting');
    window.setTimeout(() => {
      setReceipt(`页面「${values.name.trim()}」· ${values.kind} · 负责人 ${values.owner.trim()}${values.releaseDate ? ` · 计划 ${values.releaseDate}` : ''}`);
      setStatus('success');
    }, 900);
  };

  const resultVariant: AlertVariant = status === 'success'
    ? 'success'
    : status === 'submitting'
      ? 'info'
      : 'error';

  return (
    <section className="form-page" aria-labelledby="form-page-title">
      <div className="form-intro">
        <h1 id="form-page-title">新建页面申请</h1>
        <p>用已经准备好的表单组件组成一个真实可用的示例：填写、校验、提交并获得结果，全部在前端完成。</p>
      </div>

      <div className="form-layout">
        <form className="form-body" onSubmit={handleSubmit} noValidate>
          <Input
            id="form-field-name"
            label="页面名称"
            value={values.name}
            onChange={(event) => setValue('name', event.target.value)}
            onBlur={() => markTouched('name')}
            aria-invalid={visibleError('name') ? true : undefined}
            helper={visibleError('name') ?? '必填，2-40 个字符，使用团队能看懂的名称。'}
          />

          <Input
            id="form-field-owner"
            label="负责人邮箱"
            type="email"
            inputMode="email"
            autoComplete="email"
            value={values.owner}
            placeholder="designer@example.com"
            onChange={(event) => setValue('owner', event.target.value)}
            onBlur={() => markTouched('owner')}
            aria-invalid={visibleError('owner') ? true : undefined}
            helper={visibleError('owner') ?? '必填，提交结果会发到这个邮箱。'}
          />

          <Input
            id="form-field-releaseDate"
            label="计划上线日期"
            type="date"
            value={values.releaseDate}
            onChange={(event) => setValue('releaseDate', event.target.value)}
            onBlur={() => markTouched('releaseDate')}
            aria-invalid={visibleError('releaseDate') ? true : undefined}
            helper={visibleError('releaseDate') ?? '选填，不能早于今天。'}
          />

          <fieldset className="page-type-picker">
            <legend>页面类型</legend>
            <div>
              {kindOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={values.kind === option.id}
                  onClick={() => setValue('kind', option.id)}
                >
                  <span>{option.label}</span>
                </button>
              ))}
            </div>
          </fieldset>

          <Switch
            checked={values.commentsEnabled}
            onCheckedChange={(checked) => setValue('commentsEnabled', checked)}
            label="允许设计评论"
            description="协作者可以在页面上留下建议。"
          />
          <Switch
            checked={values.notifyOwner}
            onCheckedChange={(checked) => setValue('notifyOwner', checked)}
            label="上线前提醒负责人"
            description="填了计划上线日期时，会在前一天提醒。"
          />

          <div className="form-actions">
            <button
              ref={submitRef}
              className="ui-button ui-button-primary"
              type="submit"
              disabled={status === 'submitting'}
            >
              {status === 'submitting'
                ? <LoaderCircle className="ui-spin" aria-hidden="true" size={17} />
                : <Send aria-hidden="true" size={17} />}
              {status === 'submitting' ? '正在提交' : '提交申请'}
            </button>
            <Button type="button" variant="secondary" onClick={resetForm}>清空</Button>
            <Link className="form-back" to="/">
              <ArrowLeft aria-hidden="true" size={16} />
              返回首页
            </Link>
          </div>

          <p className="form-status" role="status">
            {status === 'submitting'
              ? '正在提交，请稍候。'
              : status === 'success'
                ? '提交完成，已生成本地回执。'
                : submitted && errorKeys.length > 0
                  ? `还有 ${errorKeys.length} 项需要修改。`
                  : ''}
          </p>
        </form>

        <aside className="form-aside" aria-label="填写进度">
          <Alert open={resultOpen} onOpenChange={setResultOpen} returnFocusRef={submitRef} variant={resultVariant}>
            <AlertIcon />
            <AlertContent>
              <AlertTitle>
                {status === 'submitting' ? '正在提交申请' : status === 'success' ? '申请已提交' : '还有必填项未通过'}
              </AlertTitle>
              <AlertDescription>
                {status === 'submitting'
                  ? '正在本地校验并生成回执，不会调用任何后端接口。'
                  : status === 'success'
                    ? receipt
                    : '请检查标红字段后再次提交。'}
              </AlertDescription>
            </AlertContent>
            <AlertClose />
          </Alert>

          <div className="form-summary">
            <h2>当前填写内容</h2>
            <dl>
              <div><dt>页面名称</dt><dd>{values.name.trim() || '未填写'}</dd></div>
              <div><dt>负责人邮箱</dt><dd>{values.owner.trim() || '未填写'}</dd></div>
              <div><dt>计划上线日期</dt><dd>{values.releaseDate || '未填写'}</dd></div>
              <div><dt>页面类型</dt><dd>{values.kind}</dd></div>
              <div><dt>允许设计评论</dt><dd>{values.commentsEnabled ? '开启' : '关闭'}</dd></div>
              <div><dt>上线前提醒负责人</dt><dd>{values.notifyOwner ? '开启' : '关闭'}</dd></div>
            </dl>
            <p className="form-summary-foot">
              <CircleAlert aria-hidden="true" size={14} />
              本页只做前端示例，提交结果不会发送到任何服务。
            </p>
          </div>
        </aside>
      </div>
    </section>
  );
}
