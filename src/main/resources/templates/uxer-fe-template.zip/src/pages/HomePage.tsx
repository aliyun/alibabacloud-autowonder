import { ArrowRight, BellRing, Check, FormInput, MousePointerClick } from 'lucide-react';
import { Link } from '../router/router';
import { componentsPath, type ShowcaseTab } from '../router/paths';

const shortcuts: ReadonlyArray<{
  description: string;
  icon: typeof BellRing;
  id: ShowcaseTab;
  label: string;
}> = [
  { id: 'alert', label: '通知提示', description: '反馈、提醒和错误状态', icon: BellRing },
  { id: 'form', label: '表单控件', description: '输入、选择和开关', icon: FormInput },
  { id: 'actions', label: '操作按钮', description: '主次操作和加载状态', icon: MousePointerClick },
];

export function HomePage() {
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="hero-copy">
        <h1 id="hero-title">组件已经备好，直接开始设计。</h1>
        <p>修改文案、切换状态、组合交互，把这个起点变成你的应用。</p>
        <Link className="ui-button ui-button-primary hero-action" to={componentsPath()}>
          体验常用组件
          <ArrowRight aria-hidden="true" size={18} strokeWidth={1.75} />
        </Link>
      </div>

      <aside className="component-kit" aria-label="常用组件">
        <div className="component-kit-heading">
          <span>常用组件</span>
          <span className="component-count">{shortcuts.length} 个</span>
        </div>
        <div className="component-shortcuts">
          {shortcuts.map(({ description, icon: Icon, id, label }) => (
            <Link key={id} className="shortcut-link" to={componentsPath(id)}>
              <span className="shortcut-icon"><Icon aria-hidden="true" size={19} strokeWidth={1.7} /></span>
              <span><strong>{label}</strong><small>{description}</small></span>
              <ArrowRight aria-hidden="true" size={17} />
            </Link>
          ))}
        </div>
        <div className="component-kit-foot"><Check aria-hidden="true" size={15} /> 常用组件已准备好，可以直接体验</div>
      </aside>
    </section>
  );
}
