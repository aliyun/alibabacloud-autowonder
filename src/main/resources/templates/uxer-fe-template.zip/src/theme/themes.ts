export type ThemeSelection =
  | { mode: 'preset'; id: string }
  | { mode: 'custom'; accent: string };

export interface ThemeColors {
  accent: string;
  stage: string;
  stageStrong: string;
}

export interface ThemePreset extends ThemeColors {
  description: string;
  id: string;
  name: string;
}

const STORAGE_KEY = 'demo-app.theme';
const DEFAULT_SELECTION: ThemeSelection = { mode: 'preset', id: 'graphite' };

export const themePresets: ReadonlyArray<ThemePreset> = [
  {
    id: 'graphite',
    name: '石墨灰',
    description: '默认主题：白色工作面与纯黑操作色',
    accent: '#111111',
    stage: '#f0f0ed',
    stageStrong: '#e4e4df',
  },
  {
    id: 'slate-blue',
    name: '岩层蓝',
    description: '冷静的蓝灰色工作台',
    accent: '#3f5f7a',
    stage: '#e5eaee',
    stageStrong: '#d4dde4',
  },
  {
    id: 'indigo-ink',
    name: '靛墨',
    description: '低饱和靛蓝强调色',
    accent: '#4f5579',
    stage: '#e8e9ef',
    stageStrong: '#d9dbe5',
  },
  {
    id: 'clay-amber',
    name: '陶土琥珀',
    description: '适合内容页面的温和暖色',
    accent: '#9a541d',
    stage: '#f1e9df',
    stageStrong: '#e6d8c8',
  },
  {
    id: 'rose-ink',
    name: '玫瑰墨',
    description: '克制但清晰的玫瑰强调色',
    accent: '#963d5c',
    stage: '#f0e6e9',
    stageStrong: '#e4d3d9',
  },
];

export const hexPattern = /^#[0-9a-f]{6}$/i;

export function defaultThemeSelection(): ThemeSelection {
  return { ...DEFAULT_SELECTION };
}

export function isHexColor(value: string): boolean {
  return hexPattern.test(value.trim());
}

export function isAccessibleAccent(value: string): boolean {
  if (!isHexColor(value)) return false;
  return contrastRatio(normalizeHex(value), '#ffffff') >= 4.5;
}

export function resolveThemeColors(selection: ThemeSelection): ThemeColors {
  if (selection.mode === 'preset') {
    const preset = themePresets.find((entry) => entry.id === selection.id) ?? themePresets[0];
    return { accent: preset.accent, stage: preset.stage, stageStrong: preset.stageStrong };
  }
  const accent = normalizeHex(selection.accent);
  return {
    accent,
    stage: tintOf(accent, 0.92, 0.28),
    stageStrong: tintOf(accent, 0.85, 0.32),
  };
}

export function themeLabel(selection: ThemeSelection): string {
  if (selection.mode === 'custom') return `自定义 ${normalizeHex(selection.accent).toUpperCase()}`;
  return themePresets.find((entry) => entry.id === selection.id)?.name ?? themePresets[0].name;
}

export function applyThemeColors(selection: ThemeSelection, root = document.documentElement): ThemeColors {
  const colors = resolveThemeColors(selection);
  root.style.setProperty('--accent', colors.accent);
  root.style.setProperty('--stage', colors.stage);
  root.style.setProperty('--stage-strong', colors.stageStrong);
  return colors;
}

export function readStoredTheme(): ThemeSelection | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<ThemeSelection>;
    if (parsed.mode === 'preset' && typeof parsed.id === 'string'
      && themePresets.some((entry) => entry.id === parsed.id)) {
      return { mode: 'preset', id: parsed.id };
    }
    if (parsed.mode === 'custom' && typeof parsed.accent === 'string' && isAccessibleAccent(parsed.accent)) {
      return { mode: 'custom', accent: normalizeHex(parsed.accent) };
    }
  } catch {
    /* 存储不可用或数据非法时回退默认主题 */
  }
  return null;
}

export function storeTheme(selection: ThemeSelection): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(selection));
  } catch {
    /* 隐私模式下忽略持久化失败 */
  }
}

function normalizeHex(value: string): string {
  const hex = value.trim().replace('#', '');
  const short = hex.length === 3 ? hex.split('').map((char) => char + char).join('') : hex;
  return `#${short.slice(0, 6).toLowerCase()}`;
}

function toHsl(hex: string): [number, number, number] {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const lightness = (max + min) / 2;
  const delta = max - min;
  if (delta === 0) return [0, 0, lightness];
  const saturation = delta / (lightness > 0.5 ? 2 - max - min : max + min);
  const hue = max === r
    ? ((g - b) / delta + (g < b ? 6 : 0)) / 6
    : max === g
      ? ((b - r) / delta + 2) / 6
      : ((r - g) / delta + 4) / 6;
  return [hue, saturation, lightness];
}

function toHex(hue: number, saturation: number, lightness: number): string {
  const channel = (offset: number) => {
    const k = (offset + hue * 12) % 12;
    const amplitude = saturation * Math.min(lightness, 1 - lightness);
    const value = lightness - amplitude * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    return Math.round(value * 255).toString(16).padStart(2, '0');
  };
  return `#${channel(0)}${channel(8)}${channel(4)}`;
}

function tintOf(hex: string, lightness: number, saturationCap: number): string {
  const [hue, saturation] = toHsl(hex);
  return toHex(hue, Math.min(saturation, saturationCap), lightness);
}

function contrastRatio(foreground: string, background: string): number {
  const lighter = Math.max(relativeLuminance(foreground), relativeLuminance(background));
  const darker = Math.min(relativeLuminance(foreground), relativeLuminance(background));
  return (lighter + 0.05) / (darker + 0.05);
}

function relativeLuminance(hex: string): number {
  const channels = [hex.slice(1, 3), hex.slice(3, 5), hex.slice(5, 7)].map((channel) => {
    const value = parseInt(channel, 16) / 255;
    return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
}
