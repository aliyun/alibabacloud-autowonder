import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { InspectProvider } from '@uxerjs/universal-inspector/react';
import '@fontsource-variable/noto-sans-sc';
import App from './App';
import { RouterProvider } from './router/router';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <InspectProvider>
      <RouterProvider>
        <App />
      </RouterProvider>
    </InspectProvider>
  </StrictMode>,
);
